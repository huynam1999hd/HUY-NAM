extends Control

const CHESS_SCENE := "res://board/chess_mode_select.tscn"

var card_data := [
	{"title": "CỜ VUA", "icon": "♔  ♟", "subtitle": "CHIẾN THUẬT CỔ ĐIỂN", "color": Color("#7775d8"), "tag": "SẴN SÀNG"},
	{"title": "CỜ TƯỚNG", "icon": "帥  將", "subtitle": "ĐẤU TRÍ PHƯƠNG ĐÔNG", "color": Color("#d94b43"), "tag": "SẮP RA MẮT"},
	{"title": "CỜ CÁ NGỰA", "icon": "🎲  ♞", "subtitle": "ĐUA VUI CÙNG BẠN BÈ", "color": Color("#e8b83f"), "tag": "SẮP RA MẮT"},
	{"title": "CỜ VÂY", "icon": "●  ○", "subtitle": "BAO VÂY & CHIẾM LĨNH", "color": Color("#36b9b1"), "tag": "SẮP RA MẮT"}
]

func _ready() -> void:
	_build_ui()

func _build_ui() -> void:
	var bg := ColorRect.new()
	bg.color = Color("#101a35")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

	var glow := ColorRect.new()
	glow.color = Color(0.24, 0.33, 0.62, 0.22)
	glow.position = Vector2(0, 0)
	glow.size = Vector2(1280, 210)
	glow.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	glow.offset_bottom = 190
	glow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.add_child(glow)

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 34)
	margin.add_theme_constant_override("margin_right", 34)
	margin.add_theme_constant_override("margin_top", 24)
	margin.add_theme_constant_override("margin_bottom", 22)
	add_child(margin)

	var layout := VBoxContainer.new()
	layout.add_theme_constant_override("separation", 18)
	margin.add_child(layout)

	var header := HBoxContainer.new()
	header.custom_minimum_size.y = 94
	header.add_theme_constant_override("separation", 16)
	layout.add_child(header)

	var logo := PanelContainer.new()
	logo.custom_minimum_size = Vector2(88, 82)
	logo.add_theme_stylebox_override("panel", _panel_style(Color("#f5c84b"), 18, Color("#fff0a7"), 3))
	header.add_child(logo)
	var logo_text := Label.new()
	logo_text.text = "♟"
	logo_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	logo_text.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	logo_text.add_theme_font_size_override("font_size", 50)
	logo_text.add_theme_color_override("font_color", Color("#172447"))
	logo.add_child(logo_text)

	var heading := VBoxContainer.new()
	heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	heading.alignment = BoxContainer.ALIGNMENT_CENTER
	header.add_child(heading)
	var title := Label.new()
	title.text = "THẾ GIỚI CỜ"
	title.add_theme_font_size_override("font_size", 35)
	title.add_theme_color_override("font_color", Color("#fff2bd"))
	heading.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "CHỌN TRÒ CHƠI • KẾT NỐI BẠN BÈ • SO TÀI"
	subtitle.add_theme_font_size_override("font_size", 15)
	subtitle.add_theme_color_override("font_color", Color("#b8c8ee"))
	heading.add_child(subtitle)

	var profile := Button.new()
	profile.text = "👤  NGƯỜI CHƠI\n       Khách"
	profile.custom_minimum_size = Vector2(190, 64)
	profile.add_theme_font_size_override("font_size", 16)
	profile.add_theme_color_override("font_color", Color.WHITE)
	profile.add_theme_stylebox_override("normal", _panel_style(Color("#234b82"), 16, Color("#4b82bf"), 2))
	profile.add_theme_stylebox_override("hover", _panel_style(Color("#2d609f"), 16, Color("#79b2ef"), 2))
	header.add_child(profile)

	var separator := HSeparator.new()
	separator.add_theme_color_override("separator", Color(0.55, 0.68, 0.9, 0.35))
	layout.add_child(separator)

	var intro := HBoxContainer.new()
	intro.custom_minimum_size.y = 32
	layout.add_child(intro)
	var pick := Label.new()
	pick.text = "CHỌN TRÒ CHƠI"
	pick.add_theme_font_size_override("font_size", 21)
	pick.add_theme_color_override("font_color", Color.WHITE)
	intro.add_child(pick)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	intro.add_child(spacer)
	var count := Label.new()
	count.text = "04 TRÒ CHƠI"
	count.add_theme_font_size_override("font_size", 14)
	count.add_theme_color_override("font_color", Color("#b7c8eb"))
	intro.add_child(count)

	var cards := HBoxContainer.new()
	cards.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cards.add_theme_constant_override("separation", 20)
	layout.add_child(cards)
	for i in range(card_data.size()):
		cards.add_child(_make_card(i, card_data[i]))

	var footer := HBoxContainer.new()
	footer.custom_minimum_size.y = 44
	footer.add_theme_constant_override("separation", 12)
	layout.add_child(footer)
	var footer_label := Label.new()
	footer_label.text = "♟  THẾ GIỚI CỜ"
	footer_label.add_theme_font_size_override("font_size", 14)
	footer_label.add_theme_color_override("font_color", Color("#aebfe1"))
	footer_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	footer.add_child(footer_label)
	var settings := Button.new()
	settings.text = "⚙  CÀI ĐẶT"
	settings.custom_minimum_size = Vector2(132, 42)
	settings.add_theme_font_size_override("font_size", 15)
	settings.add_theme_color_override("font_color", Color.WHITE)
	settings.add_theme_stylebox_override("normal", _panel_style(Color("#29395e"), 12, Color("#53678e"), 1))
	settings.add_theme_stylebox_override("hover", _panel_style(Color("#3a4d78"), 12, Color("#8299c7"), 1))
	settings.pressed.connect(_show_message.bind("Cài đặt sẽ được bổ sung ở bước tiếp theo."))
	footer.add_child(settings)

func _make_card(index: int, data: Dictionary) -> Control:
	var outer := PanelContainer.new()
	outer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	outer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	outer.custom_minimum_size = Vector2(0, 350)
	outer.add_theme_stylebox_override("panel", _panel_style(data.color.darkened(0.28), 22, data.color.lightened(0.28), 3))

	var button := Button.new()
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.size_flags_vertical = Control.SIZE_EXPAND_FILL
	button.text = data.icon + "\n\n" + data.title + "\n\n" + data.subtitle + "\n\n" + data.tag
	button.alignment = HORIZONTAL_ALIGNMENT_CENTER
	button.add_theme_font_size_override("font_size", 22 if index != 2 else 20)
	button.add_theme_color_override("font_color", Color("#fff9e8"))
	button.add_theme_color_override("font_hover_color", Color.WHITE)
	button.add_theme_color_override("font_pressed_color", Color.WHITE)
	button.add_theme_stylebox_override("normal", _panel_style(data.color, 18, Color(1, 1, 1, 0.28), 2))
	button.add_theme_stylebox_override("hover", _panel_style(data.color.lightened(0.12), 18, Color("#fff1b8"), 3))
	button.add_theme_stylebox_override("pressed", _panel_style(data.color.darkened(0.12), 18, Color("#fff1b8"), 3))
	button.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	button.pressed.connect(_on_card_pressed.bind(index))
	outer.add_child(button)
	return outer

func _panel_style(fill: Color, radius: int, border: Color, border_width: int) -> StyleBoxFlat:
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = fill
	style.corner_radius_top_left = radius
	style.corner_radius_top_right = radius
	style.corner_radius_bottom_left = radius
	style.corner_radius_bottom_right = radius
	style.border_color = border
	style.set_border_width_all(border_width)
	style.shadow_color = Color(0, 0, 0, 0.22)
	style.shadow_size = 7
	style.content_margin_left = 14
	style.content_margin_right = 14
	style.content_margin_top = 14
	style.content_margin_bottom = 14
	return style

func _on_card_pressed(index: int) -> void:
	if index == 0:
		get_tree().change_scene_to_file(CHESS_SCENE)
	else:
		_show_message(str(card_data[index].title) + " sẽ được bổ sung sau. Hiện tại chúng ta đang hoàn thiện khung sảnh 4 trò chơi.")

func _show_message(message: String) -> void:
	var dialog := AcceptDialog.new()
	dialog.title = "THẾ GIỚI CỜ"
	dialog.dialog_text = message
	add_child(dialog)
	dialog.popup_centered()
	dialog.confirmed.connect(dialog.queue_free)
