extends Control

const START_MENU := "res://board/start_menu.tscn"
const FRIENDS_MENU := "res://board/friends_room.tscn"

func _ready() -> void:
	_build_ui()

func _build_ui() -> void:
	var bg := ColorRect.new()
	bg.color = Color("#101a35")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 44)
	margin.add_theme_constant_override("margin_right", 44)
	margin.add_theme_constant_override("margin_top", 30)
	margin.add_theme_constant_override("margin_bottom", 30)
	add_child(margin)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 22)
	margin.add_child(root)
	var back := Button.new()
	back.text = "←  QUAY LẠI SẢNH"
	back.custom_minimum_size = Vector2(190, 46)
	back.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	back.pressed.connect(func(): get_tree().change_scene_to_file("res://main_hub.tscn"))
	root.add_child(back)
	var title := Label.new()
	title.text = "CỜ VUA"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 42)
	title.add_theme_color_override("font_color", Color("#fff0b1"))
	root.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "CHỌN CÁCH CHƠI"
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 17)
	subtitle.add_theme_color_override("font_color", Color("#b8c8ee"))
	root.add_child(subtitle)
	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(spacer)
	var cards := HBoxContainer.new()
	cards.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cards.add_theme_constant_override("separation", 24)
	root.add_child(cards)
	cards.add_child(_make_card("♟", "VS BOT", "Challenge the computer", Color("#5657a8"), func():
		GameSettings.mode = GameSettings.Mode.VS_BOT
		get_tree().change_scene_to_file(START_MENU)))
	cards.add_child(_make_card("⚔", "VS PLAYER", "Play online", Color("#147d91"), func():
		GameSettings.mode = GameSettings.Mode.VS_PERSON
		get_tree().change_scene_to_file(START_MENU)))
	cards.add_child(_make_card("✉", "VS FRIENDS", "Invite a friend by room number", Color("#b87922"), func():
		get_tree().change_scene_to_file(FRIENDS_MENU)))
	var bottom := Control.new()
	bottom.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(bottom)

func _make_card(icon_text: String, heading: String, description: String, color: Color, callback: Callable) -> Control:
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.custom_minimum_size = Vector2(0, 300)
	var style := StyleBoxFlat.new()
	style.bg_color = color.darkened(0.22)
	style.border_color = color.lightened(0.35)
	style.set_border_width_all(3)
	style.set_corner_radius_all(22)
	style.content_margin_left = 10
	style.content_margin_right = 10
	style.content_margin_top = 10
	style.content_margin_bottom = 10
	panel.add_theme_stylebox_override("panel", style)
	var button := Button.new()
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.size_flags_vertical = Control.SIZE_EXPAND_FILL
	button.text = icon_text + "\n\n" + heading + "\n\n" + description
	button.alignment = HORIZONTAL_ALIGNMENT_CENTER
	button.add_theme_font_size_override("font_size", 23)
	button.add_theme_color_override("font_color", Color("#fff9e8"))
	var normal := StyleBoxFlat.new()
	normal.bg_color = color
	normal.set_corner_radius_all(18)
	button.add_theme_stylebox_override("normal", normal)
	var hover := StyleBoxFlat.new()
	hover.bg_color = color.lightened(0.13)
	hover.border_color = Color("#fff0b1")
	hover.set_border_width_all(3)
	hover.set_corner_radius_all(18)
	button.add_theme_stylebox_override("hover", hover)
	button.pressed.connect(callback)
	panel.add_child(button)
	return panel
