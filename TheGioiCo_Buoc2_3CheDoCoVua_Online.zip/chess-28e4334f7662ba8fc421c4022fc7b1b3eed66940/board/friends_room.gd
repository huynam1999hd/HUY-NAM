extends Control

const BOARD_SCENE_PATH := "res://board/mainboard.tscn"
const MODE_SELECT_PATH := "res://board/chess_mode_select.tscn"

var room_number_label: Label
var status_label: Label
var create_button: Button
var join_button: Button
var room_input: LineEdit
var _busy := false

func _ready() -> void:
	_build_ui()
	NetworkManager.player_connected.connect(_on_connected)
	NetworkManager.connection_failed.connect(_on_connection_failed)
	NetworkManager.invite_code_ready.connect(_on_invite_code_ready)

func _build_ui() -> void:
	var bg := ColorRect.new()
	bg.color = Color("#101a35")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(660, 0)
	var style := StyleBoxFlat.new()
	style.bg_color = Color("#1c2b4c")
	style.border_color = Color("#e5b84b")
	style.set_border_width_all(2)
	style.set_corner_radius_all(22)
	style.content_margin_left = 28
	style.content_margin_right = 28
	style.content_margin_top = 26
	style.content_margin_bottom = 26
	panel.add_theme_stylebox_override("panel", style)
	center.add_child(panel)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 16)
	panel.add_child(col)
	var back := Button.new()
	back.text = "←  QUAY LẠI"
	back.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	back.pressed.connect(func(): get_tree().change_scene_to_file(MODE_SELECT_PATH))
	col.add_child(back)
	var title := Label.new()
	title.text = "MỜI BẠN CHƠI CỜ VUA"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 29)
	title.add_theme_color_override("font_color", Color("#fff0b1"))
	col.add_child(title)
	var description := Label.new()
	description.text = "Tạo phòng online, gửi số phòng cho bạn hoặc nhập số phòng bạn nhận được."
	description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	description.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	description.add_theme_color_override("font_color", Color("#c1cde5"))
	col.add_child(description)
	var room_title := Label.new()
	room_title.text = "SỐ PHÒNG CỦA BẠN"
	room_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	room_title.add_theme_font_size_override("font_size", 15)
	room_title.add_theme_color_override("font_color", Color("#e5b84b"))
	col.add_child(room_title)
	room_number_label = Label.new()
	room_number_label.text = "------"
	room_number_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	room_number_label.add_theme_font_size_override("font_size", 38)
	room_number_label.add_theme_color_override("font_color", Color.WHITE)
	col.add_child(room_number_label)
	create_button = Button.new()
	create_button.text = "TẠO PHÒNG ONLINE"
	create_button.custom_minimum_size.y = 54
	create_button.pressed.connect(_on_create_room)
	col.add_child(create_button)
	var sep := HSeparator.new()
	col.add_child(sep)
	var join_title := Label.new()
	join_title.text = "THAM GIA PHÒNG"
	join_title.add_theme_font_size_override("font_size", 16)
	join_title.add_theme_color_override("font_color", Color("#e5b84b"))
	col.add_child(join_title)
	room_input = LineEdit.new()
	room_input.placeholder_text = "Nhập số phòng của bạn bè"
	room_input.alignment = HORIZONTAL_ALIGNMENT_CENTER
	room_input.custom_minimum_size.y = 48
	col.add_child(room_input)
	join_button = Button.new()
	join_button.text = "THAM GIA"
	join_button.custom_minimum_size.y = 54
	join_button.pressed.connect(_on_join_room)
	col.add_child(join_button)
	status_label = Label.new()
	status_label.text = "Lưu ý: kết nối Internet hiện tại của project gốc cần cấu hình mạng/port; chưa có máy chủ trung tâm để ghép phòng tự động."
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status_label.add_theme_color_override("font_color", Color("#e8c980"))
	col.add_child(status_label)

func _on_create_room() -> void:
	if _busy:
		return
	NetworkManager.local_profile = ProfileManager.get_profile_dict()
	status_label.text = "Đang tạo phòng online..."
	_busy = true
	create_button.disabled = true
	join_button.disabled = true
	NetworkManager.host_game_internet()

func _on_invite_code_ready(code: String) -> void:
	if code.is_empty():
		status_label.text = "Không lấy được mã phòng. Kiểm tra kết nối và cấu hình mạng."
		_reset_buttons()
		return
	room_number_label.text = code
	DisplayServer.clipboard_set(code)
	status_label.text = "Đã tạo phòng. Mã phòng đã được sao chép; gửi mã này cho bạn bè. Kết nối Internet có thể cần mở cổng UDP %d trên router." % NetworkManager.GAME_PORT

func _on_join_room() -> void:
	if _busy:
		return
	var code := room_input.text.strip_edges()
	if code.is_empty():
		status_label.text = "Bạn hãy nhập số phòng trước."
		return
	NetworkManager.local_profile = ProfileManager.get_profile_dict()
	if not NetworkManager.join_with_code(code):
		status_label.text = "Số phòng không hợp lệ. Hãy kiểm tra lại mã phòng."
		return
	_busy = true
	create_button.disabled = true
	join_button.disabled = true
	status_label.text = "Đang kết nối vào phòng..."

func _on_connected(profile: Dictionary) -> void:
	GameSettings.mode = GameSettings.Mode.ONLINE
	GameSettings.opponent_name = profile.get("name", "Bạn bè")
	GameSettings.opponent_elo = profile.get("elo", 1200)
	GameSettings.local_player_color = 0 if NetworkManager.is_host else 1
	get_tree().change_scene_to_file(BOARD_SCENE_PATH)

func _on_connection_failed() -> void:
	status_label.text = "Kết nối thất bại. Hãy kiểm tra mạng và số phòng."
	_reset_buttons()

func _reset_buttons() -> void:
	_busy = false
	create_button.disabled = false
	join_button.disabled = false
