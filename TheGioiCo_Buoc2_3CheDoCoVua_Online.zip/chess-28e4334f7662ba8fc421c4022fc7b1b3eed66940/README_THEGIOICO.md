# THẾ GIỚI CỜ — Bước 1: Sảnh chọn trò chơi

## Thay đổi trong bản này
- Chuyển cửa sổ khởi động sang khung ngang 1280×720.
- Thêm sảnh chính với 4 thẻ: Cờ vua, Cờ tướng, Cờ cá ngựa, Cờ vây.
- Các thẻ co giãn theo chiều rộng, thuận tiện mở rộng thêm trò chơi về sau.
- Nhấn thẻ Cờ vua để vào màn hình cờ vua gốc của project.
- Ba thẻ còn lại hiện thông báo chưa triển khai; đây mới là khung giao diện bước đầu.

## Mở project
1. Giải nén toàn bộ ZIP vào một thư mục.
2. Mở Godot 4.7.2.
3. Chọn Import, trỏ tới file `project.godot` trong thư mục vừa giải nén.
4. Nhấn Run Project (F6/F5 theo giao diện Godot).

## Lưu ý
Đây là bản giao diện bước 1 dựa trên project cờ vua gốc. Hãy giữ lại toàn bộ thư mục và file tài nguyên trong ZIP. Mã nguồn cờ vua gốc vẫn được giữ nguyên; màn hình khởi động mới nằm trong `main_hub.gd` và `main_hub.tscn`.
