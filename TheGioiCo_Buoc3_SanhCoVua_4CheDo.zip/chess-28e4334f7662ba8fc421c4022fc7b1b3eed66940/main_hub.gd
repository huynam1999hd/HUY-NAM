extends Control

const BOT_SCENE := "res://board/start_menu.tscn"
const FRIENDS_SCENE := "res://board/friends_room.tscn"
const ONLINE_SCENE := "res://board/online_menu.tscn"

var palette := [Color("#e94236"), Color("#e9b900"), Color("#16b99f"), Color("#3489c9")]
var cards := [
	{"title":"ĐẤU NHANH", "icon":"⏱", "lines":"Classic / Rapid / Blitz\nCược vàng & Elo", "action":0},
	{"title":"GIẢI ĐẤU", "icon":"🏆", "lines":"Knockout 8 người\nArena chuỗi thắng", "action":1},
	{"title":"ĐẤU BẠN BÈ", "icon":"♟  ♟", "lines":"Tạo phòng trực tuyến\nChơi chung 1 máy", "action":2},
	{"title":"ĐẤU VỚI MÁY", "icon":"🤖", "lines":"Easy / Medium / Hard\nLuyện tập (Hint / Undo)", "action":3}
]

func _ready() -> void:
	_build_ui()

func _build_ui() -> void:
	var bg := ColorRect.new()
	bg.color = Color("#888888")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var wash := ColorRect.new()
	wash.color = Color(0.12,0.15,0.2,0.12)
	wash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	wash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(wash)

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for key in ["margin_left","margin_right"]: margin.add_theme_constant_override(key, 34)
	margin.add_theme_constant_override("margin_top", 18)
	margin.add_theme_constant_override("margin_bottom", 12)
	add_child(margin)
	var root := VBoxContainer.new(); root.add_theme_constant_override("separation", 12); margin.add_child(root)

	var header := HBoxContainer.new(); header.custom_minimum_size.y = 76; header.add_theme_constant_override("separation", 14); root.add_child(header)
	var avatar := Label.new(); avatar.text = "◉"; avatar.custom_minimum_size = Vector2(70,68); avatar.vertical_alignment = VERTICAL_ALIGNMENT_CENTER; avatar.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; avatar.add_theme_font_size_override("font_size",54); avatar.add_theme_color_override("font_color",Color("#f2f2f2")); header.add_child(avatar)
	var profile := VBoxContainer.new(); profile.size_flags_horizontal = Control.SIZE_EXPAND_FILL; profile.alignment = BoxContainer.ALIGNMENT_CENTER; header.add_child(profile)
	var name := Label.new(); name.text = "NGƯỜI CHƠI"; name.add_theme_font_size_override("font_size",23); name.add_theme_color_override("font_color",Color.WHITE); profile.add_child(name)
	var level := Label.new(); level.text = "LV. 1     ▰▰▰▱▱  20%"; level.add_theme_font_size_override("font_size",15); level.add_theme_color_override("font_color",Color("#eaf4ff")); profile.add_child(level)
	var currency := Label.new(); currency.text = "🟡 15,250  ＋     💎 120  ＋"; currency.custom_minimum_size.x = 310; currency.vertical_alignment = VERTICAL_ALIGNMENT_CENTER; currency.add_theme_font_size_override("font_size",21); currency.add_theme_color_override("font_color",Color("#fff4b2")); header.add_child(currency)
	for item in ["▤","♧","⚙"]:
		var b := Button.new(); b.text=item; b.custom_minimum_size=Vector2(48,48); b.add_theme_font_size_override("font_size",25); _style_button(b,Color("#777777"),Color.WHITE,10); b.pressed.connect(_show_message.bind("Tính năng này sẽ được bổ sung sau.")); header.add_child(b)

	var event_row := HBoxContainer.new(); event_row.alignment = BoxContainer.ALIGNMENT_CENTER; event_row.custom_minimum_size.y=78; root.add_child(event_row)
	var event_panel := PanelContainer.new(); event_panel.custom_minimum_size=Vector2(470,72); _style_panel(event_panel,Color("#f2f2f2"),Color("#ffffff"),3,15); event_row.add_child(event_panel)
	var event_line := HBoxContainer.new(); event_line.add_theme_constant_override("separation",15); event_panel.add_child(event_line)
	var event_text := Label.new(); event_text.text="📢 EVENT / PASS BANNER\nMÙA GIẢI HOÀNG GIA - NHẬN QUÀ!"; event_text.size_flags_horizontal=Control.SIZE_EXPAND_FILL; event_text.vertical_alignment=VERTICAL_ALIGNMENT_CENTER; event_text.add_theme_font_size_override("font_size",18); event_text.add_theme_color_override("font_color",Color("#242424")); event_line.add_child(event_text)
	var event_btn := Button.new(); event_btn.text="XEM"; event_btn.custom_minimum_size=Vector2(84,42); _style_button(event_btn,Color.WHITE,Color("#202020"),10); event_btn.pressed.connect(_show_message.bind("Sự kiện sẽ được cập nhật sau.")); event_line.add_child(event_btn)

	var section := HBoxContainer.new(); section.custom_minimum_size.y=32; root.add_child(section)
	var label := Label.new(); label.text="CHỌN CHẾ ĐỘ CỜ VUA"; label.add_theme_font_size_override("font_size",19); label.add_theme_color_override("font_color",Color.WHITE); section.add_child(label)
	var fill := Control.new(); fill.size_flags_horizontal=Control.SIZE_EXPAND_FILL; section.add_child(fill)
	var count := Label.new(); count.text="4 CHẾ ĐỘ"; count.add_theme_font_size_override("font_size",14); count.add_theme_color_override("font_color",Color("#eeeeee")); section.add_child(count)

	var card_row := HBoxContainer.new(); card_row.size_flags_vertical=Control.SIZE_EXPAND_FILL; card_row.add_theme_constant_override("separation",22); root.add_child(card_row)
	for i in range(cards.size()): card_row.add_child(_make_card(i,cards[i]))

	var footer := HBoxContainer.new(); footer.custom_minimum_size.y=42; footer.add_theme_constant_override("separation",24); root.add_child(footer)
	for item in ["⌂  Trang chủ","🏆  BXH","▤  Cửa hàng","▧  Nhiệm vụ","♙  Tủ đồ"]:
		var nav := Button.new(); nav.text=item; nav.size_flags_horizontal=Control.SIZE_EXPAND_FILL; nav.add_theme_font_size_override("font_size",15); _style_button(nav,Color(0,0,0,0),Color("#f5f5f5"),8); nav.pressed.connect(_show_message.bind("Mục này sẽ được phát triển ở bước tiếp theo.")); footer.add_child(nav)

func _make_card(i:int, data:Dictionary) -> Control:
	var panel := PanelContainer.new(); panel.size_flags_horizontal=Control.SIZE_EXPAND_FILL; panel.size_flags_vertical=Control.SIZE_EXPAND_FILL; panel.custom_minimum_size=Vector2(0,350)
	_style_panel(panel,palette[i].darkened(0.12),Color("#262626"),3,24)
	var b := Button.new(); b.size_flags_horizontal=Control.SIZE_EXPAND_FILL; b.size_flags_vertical=Control.SIZE_EXPAND_FILL; b.alignment=HORIZONTAL_ALIGNMENT_LEFT; b.text=data.icon+"\n\n"+data.title+"\n\n• "+data.lines.replace("\n","\n• ")+"\n\n[  "+(["CHƠI NGAY","THAM GIA","THÁCH ĐẤU","LUYỆN TẬP"][i])+"  ]"; b.add_theme_font_size_override("font_size",19); b.add_theme_color_override("font_color",Color("#ffffff")); b.add_theme_color_override("font_hover_color",Color.WHITE); b.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	_style_button(b,palette[i],Color.WHITE,20); b.add_theme_stylebox_override("hover",_button_style(palette[i].lightened(0.1),Color.WHITE,20,3)); b.pressed.connect(_on_card.bind(i)); panel.add_child(b); return panel

func _on_card(i:int) -> void:
	match i:
		0:
			GameSettings.mode=GameSettings.Mode.VS_PERSON
			get_tree().change_scene_to_file(ONLINE_SCENE)
		1: _show_message("GIẢI ĐẤU\nChế độ giải đấu sẽ được phát triển sau khi hoàn thiện các chế độ cốt lõi.")
		2: get_tree().change_scene_to_file(FRIENDS_SCENE)
		3:
			GameSettings.mode=GameSettings.Mode.VS_BOT
			get_tree().change_scene_to_file(BOT_SCENE)

func _button_style(fill:Color,border:Color,radius:int,width:int=1) -> StyleBoxFlat:
	var s:=StyleBoxFlat.new(); s.bg_color=fill; s.border_color=border; s.set_border_width_all(width); s.set_corner_radius_all(radius); s.content_margin_left=12; s.content_margin_right=12; s.content_margin_top=10; s.content_margin_bottom=10; return s
func _style_button(b:Button,fill:Color,border:Color,radius:int) -> void:
	b.add_theme_stylebox_override("normal",_button_style(fill,border,radius)); b.add_theme_stylebox_override("hover",_button_style(fill.lightened(0.1),border,radius,2)); b.add_theme_stylebox_override("pressed",_button_style(fill.darkened(0.1),border,radius,2))
func _style_panel(p:PanelContainer,fill:Color,border:Color,width:int,radius:int) -> void:
	var s:=StyleBoxFlat.new(); s.bg_color=fill; s.border_color=border; s.set_border_width_all(width); s.set_corner_radius_all(radius); s.content_margin_left=12; s.content_margin_right=12; s.content_margin_top=12; s.content_margin_bottom=12; s.shadow_color=Color(0,0,0,0.22); s.shadow_size=5; p.add_theme_stylebox_override("panel",s)
func _show_message(message:String) -> void:
	var d:=AcceptDialog.new(); d.title="THẾ GIỚI CỜ"; d.dialog_text=message; add_child(d); d.confirmed.connect(d.queue_free); d.popup_centered()
