# THẾ GIỚI CỜ — Bước 3: Tập trung vào cờ vua

## Màn hình hiện có
- Sảnh ngang với 4 thẻ: Đấu nhanh, Giải đấu, Đấu bạn bè, Đấu với máy.
- Đấu với máy: chọn độ khó, thời gian và màu quân; ngẫu nhiên là mặc định.
- Đấu bạn bè: 3 thẻ 2 người cùng máy, tạo phòng, vào phòng; có hiển thị và sao chép số phòng.
- Bàn cờ và các logic gốc được giữ lại.

## Mở project
Mở `project.godot` bằng Godot 4.7.2 rồi chạy project.

## Giới hạn hiện tại
Đấu nhanh đang mở giao diện online có sẵn; Giải đấu và hai người cùng máy là khung giao diện/chưa tích hợp gameplay hoàn chỉnh. Tạo/vào phòng vẫn dựa vào kết nối mạng trực tiếp từ project gốc; chưa có máy chủ trung tâm để quản lý phòng qua Internet. Hãy thử nghiệm trong Godot trước khi phát hành.
