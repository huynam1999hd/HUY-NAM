extends Control
const BOARD_SCENE_PATH := "res://board/mainboard.tscn"
const MAIN_SCENE := "res://main_hub.tscn"
var room_number_label:Label
var status_label:Label
var create_button:Button
var join_button:Button
var room_input:LineEdit
var _busy:=false
var page:=0 # 0 selection, 1 create, 2 join

func _ready()->void:
	_build_ui()
	NetworkManager.player_connected.connect(_on_connected)
	NetworkManager.connection_failed.connect(_on_connection_failed)
	NetworkManager.invite_code_ready.connect(_on_invite_code_ready)

func _build_ui()->void:
	var bg:=ColorRect.new(); bg.color=Color("#20284b"); bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(bg)
	var margin:=MarginContainer.new(); margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); margin.add_theme_constant_override("margin_left",45); margin.add_theme_constant_override("margin_right",45); margin.add_theme_constant_override("margin_top",24); margin.add_theme_constant_override("margin_bottom",24); add_child(margin)
	var root:=VBoxContainer.new(); root.add_theme_constant_override("separation",18); margin.add_child(root)
	var top:=HBoxContainer.new(); root.add_child(top)
	var back:=Button.new(); back.text="← QUAY LẠI"; back.custom_minimum_size=Vector2(150,45); _style(back,Color("#3a4c77"),12); back.pressed.connect(_go_back); top.add_child(back)
	var fill:=Control.new(); fill.size_flags_horizontal=Control.SIZE_EXPAND_FILL; top.add_child(fill)
	var title:=Label.new(); title.text="ĐẤU BẠN BÈ"; title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",36); title.add_theme_color_override("font_color",Color("#ffe9a1")); root.add_child(title)
	var subtitle:=Label.new(); subtitle.text="Chơi cùng người thân hoặc mời bạn qua số phòng"; subtitle.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; subtitle.add_theme_font_size_override("font_size",17); subtitle.add_theme_color_override("font_color",Color("#d4def6")); root.add_child(subtitle)
	var card_row:=HBoxContainer.new(); card_row.size_flags_vertical=Control.SIZE_EXPAND_FILL; card_row.add_theme_constant_override("separation",22); root.add_child(card_row)
	card_row.add_child(_card("♟  ♟","2 NGƯỜI CHƠI\nCÙNG 1 MÁY","Hai người thay phiên trên cùng thiết bị",Color("#3e91c9"),func():_local_play()))
	card_row.add_child(_card("＋","TẠO PHÒNG","Tạo phòng và chia sẻ số phòng",Color("#1bb69e"),func():_show_create()))
	card_row.add_child(_card("⌕","VÀO PHÒNG","Nhập số phòng bạn bè gửi",Color("#e3ad28"),func():_show_join()))
	var details:=PanelContainer.new(); details.custom_minimum_size.y=205; _panel(details,Color("#172440"),Color("#7789b3"),2,18); root.add_child(details)
	var box:=VBoxContainer.new(); box.add_theme_constant_override("separation",10); details.add_child(box)
	var room_title:=Label.new(); room_title.text="SỐ PHÒNG / MỜI BẠN"; room_title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; room_title.add_theme_font_size_override("font_size",16); room_title.add_theme_color_override("font_color",Color("#f2d77d")); box.add_child(room_title)
	room_number_label=Label.new(); room_number_label.text="------"; room_number_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; room_number_label.add_theme_font_size_override("font_size",28); room_number_label.add_theme_color_override("font_color",Color.WHITE); box.add_child(room_number_label)
	room_input=LineEdit.new(); room_input.placeholder_text="Nhập số phòng để vào phòng bạn bè"; room_input.alignment=HORIZONTAL_ALIGNMENT_CENTER; room_input.custom_minimum_size.y=42; box.add_child(room_input)
	var actions:=HBoxContainer.new(); actions.alignment=BoxContainer.ALIGNMENT_CENTER; actions.add_theme_constant_override("separation",12); box.add_child(actions)
	create_button=Button.new(); create_button.text="TẠO PHÒNG ONLINE"; create_button.custom_minimum_size=Vector2(230,45); _style(create_button,Color("#16a88f"),12); create_button.pressed.connect(_on_create_room); actions.add_child(create_button)
	var copy:=Button.new(); copy.text="SAO CHÉP SỐ PHÒNG"; copy.custom_minimum_size=Vector2(220,45); _style(copy,Color("#3b73c7"),12); copy.pressed.connect(_copy_code); actions.add_child(copy)
	join_button=Button.new(); join_button.text="VÀO PHÒNG"; join_button.custom_minimum_size=Vector2(170,45); _style(join_button,Color("#d7a322"),12); join_button.pressed.connect(_on_join_room); actions.add_child(join_button)
	status_label=Label.new(); status_label.text="Chọn một thẻ phía trên để bắt đầu. Chức năng online cần máy chủ trung tâm hoặc cấu hình mạng phù hợp."; status_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; status_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; status_label.add_theme_color_override("font_color",Color("#e5d49a")); status_label.add_theme_font_size_override("font_size",13); box.add_child(status_label)

func _card(icon_text:String,heading:String,desc:String,color:Color,action:Callable)->Control:
	var p:=PanelContainer.new(); p.size_flags_horizontal=Control.SIZE_EXPAND_FILL; p.size_flags_vertical=Control.SIZE_EXPAND_FILL; p.custom_minimum_size=Vector2(0,250); _panel(p,color.darkened(0.1),color.lightened(0.3),3,22)
	var b:=Button.new(); b.size_flags_horizontal=Control.SIZE_EXPAND_FILL; b.size_flags_vertical=Control.SIZE_EXPAND_FILL; b.text=icon_text+"\n\n"+heading+"\n\n"+desc; b.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; b.add_theme_font_size_override("font_size",22); b.add_theme_color_override("font_color",Color.WHITE); _style(b,color,18); b.pressed.connect(action); p.add_child(b); return p
func _panel(p:PanelContainer,fill:Color,border:Color,width:int,radius:int)->void:
	var s:=StyleBoxFlat.new(); s.bg_color=fill; s.border_color=border; s.set_border_width_all(width); s.set_corner_radius_all(radius); s.content_margin_left=14; s.content_margin_right=14; s.content_margin_top=12; s.content_margin_bottom=12; p.add_theme_stylebox_override("panel",s)
func _style(b:Button,fill:Color,radius:int)->void:
	var s:=StyleBoxFlat.new(); s.bg_color=fill; s.border_color=fill.lightened(0.25); s.set_border_width_all(2); s.set_corner_radius_all(radius); s.content_margin_left=10; s.content_margin_right=10; s.content_margin_top=8; s.content_margin_bottom=8; b.add_theme_stylebox_override("normal",s); var h:=s.duplicate() as StyleBoxFlat; h.bg_color=fill.lightened(0.1); b.add_theme_stylebox_override("hover",h)
func _show_create()->void:
	status_label.text="Đã chọn TẠO PHÒNG. Nhấn TẠO PHÒNG ONLINE để tạo mã phòng."
func _show_join()->void:
	room_input.grab_focus(); status_label.text="Đã chọn VÀO PHÒNG. Nhập mã phòng rồi nhấn VÀO PHÒNG."
func _local_play()->void:
	status_label.text="Chế độ hai người trên cùng máy sẽ được kết nối với luật bàn cờ ở bước tiếp theo."
func _on_create_room()->void:
	if _busy:return
	NetworkManager.local_profile=ProfileManager.get_profile_dict(); status_label.text="Đang tạo phòng online..."; _busy=true; create_button.disabled=true; join_button.disabled=true; NetworkManager.host_game_internet()
func _on_invite_code_ready(code:String)->void:
	if code.is_empty(): status_label.text="Không tạo được số phòng. Kiểm tra kết nối mạng."; _reset_buttons(); return
	room_number_label.text=code; DisplayServer.clipboard_set(code); status_label.text="Đã tạo phòng. Số phòng được sao chép; gửi cho bạn bè. Lưu ý: hệ thống hiện chưa có máy chủ trung tâm nên có thể cần cấu hình mạng/UDP."
func _on_join_room()->void:
	if _busy:return
	var code:=room_input.text.strip_edges()
	if code.is_empty(): status_label.text="Hãy nhập số phòng trước."; return
	NetworkManager.local_profile=ProfileManager.get_profile_dict()
	if not NetworkManager.join_with_code(code): status_label.text="Số phòng không hợp lệ. Kiểm tra lại."; return
	_busy=true; create_button.disabled=true; join_button.disabled=true; status_label.text="Đang kết nối vào phòng..."
func _on_connected(profile:Dictionary)->void:
	GameSettings.mode=GameSettings.Mode.ONLINE; GameSettings.opponent_name=profile.get("name","Bạn bè"); GameSettings.opponent_elo=profile.get("elo",1200); GameSettings.local_player_color=0 if NetworkManager.is_host else 1; get_tree().change_scene_to_file(BOARD_SCENE_PATH)
func _on_connection_failed()->void:
	status_label.text="Kết nối thất bại. Kiểm tra mạng và số phòng."; _reset_buttons()
func _reset_buttons()->void:
	_busy=false; create_button.disabled=false; join_button.disabled=false
func _copy_code()->void:
	if room_number_label.text!="------": DisplayServer.clipboard_set(room_number_label.text); status_label.text="Đã sao chép số phòng."
	else: status_label.text="Chưa có số phòng. Hãy tạo phòng trước."
func _go_back()->void:
	get_tree().change_scene_to_file(MAIN_SCENE)
