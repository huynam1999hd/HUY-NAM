extends Control

const BOARD_SCENE_PATH := "res://board/mainboard.tscn"
const ONLINE_MENU_PATH := "res://board/online_menu.tscn"
const TIME_OPTIONS = [
	{"label":"CLASSICAL · 30 MIN", "seconds":1800},
	{"label":"RAPID · 10 MIN", "seconds":600},
	{"label":"BLITZ · 5 MIN", "seconds":300},
	{"label":"KHÔNG GIỚI HẠN", "seconds":0}
]
var difficulty := 1
var time_index := 1
var side := 2 # 0 white, 1 black, 2 random
var difficulty_buttons:Array[Button]=[]
var time_buttons:Array[Button]=[]
var side_buttons:Array[Button]=[]
var start_button:Button

func _ready() -> void:
	_build_ui()

func _build_ui() -> void:
	var bg:=ColorRect.new(); bg.color=Color("#39328f"); bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(bg)
	var glow:=ColorRect.new(); glow.color=Color(0.55,0.25,0.78,0.5); glow.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE); glow.offset_top=-240; glow.mouse_filter=Control.MOUSE_FILTER_IGNORE; add_child(glow)
	var margin:=MarginContainer.new(); margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); margin.add_theme_constant_override("margin_left",45); margin.add_theme_constant_override("margin_right",45); margin.add_theme_constant_override("margin_top",14); margin.add_theme_constant_override("margin_bottom",18); add_child(margin)
	var root:=VBoxContainer.new(); root.add_theme_constant_override("separation",13); margin.add_child(root)
	var top:=HBoxContainer.new(); top.custom_minimum_size.y=54; root.add_child(top)
	var back:=Button.new(); back.text="↩"; back.custom_minimum_size=Vector2(74,50); _style_button(back,Color("#245da0"),12); back.pressed.connect(func():get_tree().change_scene_to_file("res://main_hub.tscn")); top.add_child(back)
	var wallet:=Label.new(); wallet.text="🟡 15,250  ＋       💎 120  ＋"; wallet.size_flags_horizontal=Control.SIZE_EXPAND_FILL; wallet.vertical_alignment=VERTICAL_ALIGNMENT_CENTER; wallet.add_theme_font_size_override("font_size",20); wallet.add_theme_color_override("font_color",Color("#ffe58b")); top.add_child(wallet)
	for t in ["▤","♧","⚙"]:
		var b:=Button.new(); b.text=t; b.custom_minimum_size=Vector2(48,48); _style_button(b,Color("#3e469c"),12); top.add_child(b)
	var title:=Label.new(); title.text="ĐẤU VỚI MÁY"; title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",38); title.add_theme_color_override("font_color",Color.WHITE); root.add_child(title)
	var grid:=GridContainer.new(); grid.columns=4; grid.size_flags_vertical=Control.SIZE_EXPAND_FILL; grid.add_theme_constant_override("h_separation",18); grid.add_theme_constant_override("v_separation",12); root.add_child(grid)
	var spacer:=Label.new(); spacer.text="ĐỘ KHÓ"; spacer.vertical_alignment=VERTICAL_ALIGNMENT_CENTER; spacer.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT; spacer.add_theme_font_size_override("font_size",23); spacer.add_theme_color_override("font_color",Color.WHITE); grid.add_child(spacer)
	for i in range(3):
		var b:=_option_button(["EASY","MEDIUM","HARD"][i]); b.pressed.connect(_select_difficulty.bind(i)); difficulty_buttons.append(b); grid.add_child(b)
	var time_label:=Label.new(); time_label.text="THỜI GIAN"; time_label.vertical_alignment=VERTICAL_ALIGNMENT_CENTER; time_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT; time_label.add_theme_font_size_override("font_size",22); time_label.add_theme_color_override("font_color",Color.WHITE); grid.add_child(time_label)
	for i in range(3):
		var b:=_option_button(["CLASSICAL","RAPID","BLITZ"][i]); b.pressed.connect(_select_time.bind(i)); time_buttons.append(b); grid.add_child(b)
	var side_label:=Label.new(); side_label.text="QUÂN CỦA BẠN"; side_label.vertical_alignment=VERTICAL_ALIGNMENT_CENTER; side_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT; side_label.add_theme_font_size_override("font_size",21); side_label.add_theme_color_override("font_color",Color.WHITE); grid.add_child(side_label)
	for i in range(3):
		var b:=_option_button(["TRẮNG\nĐi trước","ĐEN\nĐi sau","NGẪU NHIÊN"][i]); b.pressed.connect(_select_side.bind(i)); side_buttons.append(b); grid.add_child(b)
	var blank:=Control.new(); grid.add_child(blank)
	var note:=Label.new(); note.text="Chọn độ khó, thời gian và màu quân để bắt đầu"; note.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; note.add_theme_color_override("font_color",Color("#e4e4ff")); note.add_theme_font_size_override("font_size",14); root.add_child(note)
	start_button=Button.new(); start_button.text="BẮT ĐẦU"; start_button.custom_minimum_size=Vector2(330,76); start_button.size_flags_horizontal=Control.SIZE_SHRINK_CENTER; start_button.add_theme_font_size_override("font_size",30); _style_button(start_button,Color("#ffd52a"),18); start_button.add_theme_color_override("font_color",Color("#743b20")); start_button.pressed.connect(_on_start_pressed); root.add_child(start_button)
	_select_difficulty(difficulty); _select_time(time_index); _select_side(side)

func _option_button(text_value:String)->Button:
	var b:=Button.new(); b.text=text_value; b.custom_minimum_size=Vector2(0,92); b.size_flags_horizontal=Control.SIZE_EXPAND_FILL; b.size_flags_vertical=Control.SIZE_EXPAND_FILL; b.add_theme_font_size_override("font_size",22); _style_button(b,Color("#4f83f1"),20); return b
func _style_button(b:Button,fill:Color,radius:int)->void:
	var s:=StyleBoxFlat.new(); s.bg_color=fill; s.set_corner_radius_all(radius); s.border_color=fill.lightened(0.25); s.set_border_width_all(2); s.content_margin_left=10; s.content_margin_right=10; s.content_margin_top=8; s.content_margin_bottom=8; b.add_theme_stylebox_override("normal",s)
	var h:=s.duplicate() as StyleBoxFlat; h.bg_color=fill.lightened(0.12); b.add_theme_stylebox_override("hover",h)
func _set_selected(buttons:Array[Button],index:int)->void:
	for i in range(buttons.size()):
		var s:=StyleBoxFlat.new(); s.bg_color=Color("#ffda36") if i==index else Color("#4f83f1"); s.border_color=Color("#fff2a0") if i==index else Color("#7daeff"); s.set_border_width_all(3 if i==index else 1); s.set_corner_radius_all(18); s.content_margin_left=8; s.content_margin_right=8; s.content_margin_top=8; s.content_margin_bottom=8; buttons[i].add_theme_stylebox_override("normal",s); buttons[i].add_theme_color_override("font_color",Color("#503a36") if i==index else Color.WHITE)
func _select_difficulty(i:int)->void:
	difficulty=i; _set_selected(difficulty_buttons,i)
func _select_time(i:int)->void:
	time_index=i; _set_selected(time_buttons,i)
func _select_side(i:int)->void:
	side=i; _set_selected(side_buttons,i)
func _on_start_pressed()->void:
	GameSettings.mode=GameSettings.Mode.VS_BOT
	GameSettings.difficulty=difficulty
	GameSettings.time_control_seconds=int(TIME_OPTIONS[time_index].seconds)
	var chosen_side:=randi()%2 if side==2 else side
	GameSettings.bot_color=1 if chosen_side==0 else 0
	get_tree().change_scene_to_file(BOARD_SCENE_PATH)
